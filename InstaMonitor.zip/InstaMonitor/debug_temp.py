print('Debug: ban_watch_list contents:')
print(ban_watch_list)
